package com.example.appmilestone0

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class SignInDetailsActivity : AppCompatActivity() {
    // Initialize FirebaseAuth
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in_details)

        // Initialize FirebaseAuth instance
        mAuth = FirebaseAuth.getInstance()

        val btnSignInDetails = findViewById<Button>(R.id.btn_sign_in_details)
        val btnMap = findViewById<Button>(R.id.btn_map)
        val btnSignOut = findViewById<Button>(R.id.btn_sign_out) // Button to sign out
        val userDetailsTextView = findViewById<TextView>(R.id.userDetailsTextView)

        // Get current user
        val currentUser = mAuth.currentUser

        if (currentUser != null) {
            // Display user details in the TextView
            val userDetails = "Email: ${currentUser.email}\n" +
                    "Display Name: ${currentUser.displayName ?: "Not set"}"
            userDetailsTextView.text = userDetails
        } else {
            // No user is signed in
            Toast.makeText(this, "No user signed in", Toast.LENGTH_SHORT).show()
        }

        // Sign In Details button functionality
        btnSignInDetails.setOnClickListener {
            // Open ProfileActivity when the button is clicked
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        // Map button functionality to open MapActivity
        btnMap.setOnClickListener {
            val mapIntent = Intent(this, MapActivity::class.java)
            startActivity(mapIntent)
        }

        // Sign out functionality
        btnSignOut.setOnClickListener {
            mAuth.signOut()
            Toast.makeText(this, "Signed out successfully", Toast.LENGTH_SHORT).show()

            // Return to login screen after sign-out
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
            finish()
        }
    }
}
