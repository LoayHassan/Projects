import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = "192.168.1.102"
localhost = "127.0.0.1"
port = 55410
server_socket.bind((host, port))
server_socket.listen(5)

print("Server listening for connections...")

while True:
    client_socket, client_address = server_socket.accept()
    print(f"Accepted connection from {client_address}")

    while True:
        message = client_socket.recv(1024).decode('utf-8')
        print(f"Received from client:{message}")
        if message.upper() == "END":
            print("Connection is closed.")
            response = "Goodbye"
            client_socket.send(response.encode('utf-8'))

            break
        response = message.upper()
        client_socket.send(response.encode('utf-8'))
    break

server_socket.close()
